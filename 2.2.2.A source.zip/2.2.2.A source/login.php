<?php
$db_host = 'localhost';
$db_database ='routson';
$db_username = 'username';
$db_password = 'password';
?>