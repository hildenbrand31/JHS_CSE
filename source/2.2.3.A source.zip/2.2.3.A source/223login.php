<?php
$db_host = 'localhost';
$db_database ='your database name';
$db_username = 'your mysql user name';
$db_password = 'your mysql password';
?>